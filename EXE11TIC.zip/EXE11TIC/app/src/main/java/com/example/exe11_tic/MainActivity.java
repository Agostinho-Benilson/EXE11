package com.example.exe11_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        btn_login = findViewById(R.id.btn_login);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username.getText().toString();
                String password1 = password.getText().toString();
                String vetor[] = {"user", "User", "USER"};

                if((username1.equals("user") || username1.equals("User")  || username1.equals("USER")) && ( password1.equals("pass"))){
                    Toast.makeText(getApplicationContext(), "Login Válido" , Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(getApplicationContext(), "Login inválido" , Toast.LENGTH_LONG).show();
                }
                
                username.setText("");
                password.setText("");
            }
        });
    }
}